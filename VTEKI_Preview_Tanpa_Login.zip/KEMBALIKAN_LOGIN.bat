@echo off
chcp 65001 >nul
cd /d "%~dp0"
python "%~dp0KEMBALIKAN_LOGIN.py"
pause
