# VTEKI API — Patch contract validation (candidate)

Patch disusun dari `vteki-api-debug.zip` yang kamu unggah. Ini BUKAN jaminan semua Schemathesis test sudah lulus.

Yang diperbaiki:
- Validasi batas ID PostgreSQL INTEGER pada path, query, dan beberapa payload (agar 500 dari ID ekstrem menjadi 422).
- `OPTIONS` mengembalikan metode nyata, memprioritaskan route statis seperti `/customers/seed`.
- Daftar role dan keputusan review divalidasi sesuai schema, sehingga 422 cocok dengan OpenAPI.
- Permintaan approval tanpa draft menggunakan 409 Conflict (kondisi bisnis, bukan error bentuk request).
- Nilai float tidak menerima boolean; penanganan NUL pada beberapa teks input agar gagal dengan validasi.
- Tes regresi ditambahkan di tests/security/test_auth.py.

CARA PAKAI: di PowerShell pada folder project:

    Expand-Archive -Path "$HOME\Downloads\vteki_contract_fix.zip" -DestinationPath "..\vteki_fix_patch" -Force
    python ..\vteki_fix_patch\apply_fix.py

Jika ZIP tersimpan di folder lain, ganti path ZIP. Installer menolak menimpa file yang berbeda dari snapshot yang kamu unggah, membackup file lama di folder SEJAJAR project, dan menjalankan Ruff/Black jika terpasang.

VALIDASI:

    python -m ruff check .
    python -m black --check api worker migrations tests/security/test_auth.py tests/worker
    python -m mypy services api worker --ignore-missing-imports
    python -m pytest -q
    git diff --check
    git diff --stat

Periksa diff sebelum `git add`/`git commit`, lalu push dan periksa job Schemathesis pada GitHub Actions (PostgreSQL). Jika gagal, kirim log terbaru + langkah 'Show FastAPI Error Logs'.

CATATAN: pengujian terarah 13 kasus telah dilakukan dengan autentikasi tiruan dan SQLite di lingkungan analisis, sementara tes lengkap dengan dependensi asli dan PostgreSQL tidak bisa dijalankan di sini.
