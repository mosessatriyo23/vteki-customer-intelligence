"""Safely apply VTEKI API contract repairs from the extracted patch bundle."""
from pathlib import Path
from hashlib import sha256
import json
import shutil
import subprocess
import sys
from datetime import datetime,timezone

bundle=Path(__file__).resolve().parent
root=Path.cwd().resolve()
if not (root/'api/main.py').exists() or not (root/'pyproject.toml').exists():
    raise SystemExit('ERROR: Jalankan dari root project VTEKI (folder berisi api dan pyproject.toml).')
manifest=json.loads((bundle/'manifest.json').read_text(encoding='utf-8'))
new_files={}
errors=[]
for name,info in manifest.items():
    path=root/name
    source=bundle/'files'/name
    data=source.read_bytes()
    if sha256(data).hexdigest()!=info['new_sha256']:
        raise SystemExit('ERROR: Patch rusak atau tidak lengkap: '+name)
    old=path.read_bytes() if path.exists() else None
    digest=sha256(old).hexdigest() if old is not None else None
    if digest==info['new_sha256']:
        print('ALREADY APPLIED:',name)
        continue
    if digest!=info['old_sha256']:
        errors.append(name)
        continue
    new_files[name]=data
if errors:
    print('STOP: File lokal berbeda dari file pada ZIP yang kamu unggah:')
    for name in errors: print('  -',name)
    raise SystemExit('Tidak ada file diubah. Perlu meninjau perubahan lokal terlebih dahulu.')
if not new_files:
    print('Patch sudah diterapkan seluruhnya.')
    raise SystemExit(0)
backup=root.parent/('vteki_backup_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S'))
for name,data in new_files.items():
    path=root/name
    if path.exists():
        destination=backup/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,destination)
for name,data in new_files.items():
    path=root/name
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
    print('PATCHED:',name)
print('Backup file lama:',backup)
changed=[name for name in new_files if name.endswith('.py')]
if changed:
    for module,args in [('ruff',['check','--fix',*changed]),('black',changed)]:
        cmd=[sys.executable,'-m',module,*args]
        print('Running:', ' '.join(cmd))
        result=subprocess.run(cmd,cwd=root,check=False)
        if result.returncode:
            print('PERHATIAN:',module,'tidak berhasil; cek instalasi requirements-dev.txt dan jalankan ulang formatter.')
print('Selesai menerapkan patch. Jalankan pemeriksaan sebelum commit:')
print('  python -m ruff check .')
print('  python -m black --check api worker migrations tests/security/test_auth.py tests/worker')
print('  python -m mypy services api worker --ignore-missing-imports')
print('  python -m pytest -q')
print('  git diff --check')
print('CI Schemathesis tetap perlu diverifikasi dengan PostgreSQL.')
