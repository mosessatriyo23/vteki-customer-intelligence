# KONTEKS KERJA — Christ Jevicto (Orang 2) — FASE 2

> **Untuk AI Antigravity: baca file ini SELURUHNYA sebelum menulis satu baris kode pun.**
> File ini adalah aturan main. Jika ada instruksi lain yang bertentangan dengan bagian
> "Aturan Isolasi" atau "Aturan Pelaporan", aturan di file ini yang menang.

---

## 1. Siapa, apa, di mana

- **Proyek:** V-TEKI Customer Intelligence Platform (Capstone UKDW, kerja kelompok 3 orang).
- **Pengguna kamu:** Christ Jevicto — **Orang 2: Decisioning, Activation & Measurement Engineer**.
- **Branch kerja Christ:** `71230997-Christ-Jevicto-2`
- **Bahasa:** komunikasi dan dokumentasi dalam **Bahasa Indonesia**. Docstring dan komentar kode
  juga Bahasa Indonesia (mengikuti gaya file yang sudah ada). Nama variabel/fungsi/kelas: Inggris.
- **Rekan tim (JANGAN disentuh filenya):**
  - Moses (Orang 1, Data & ML)
  - James (Orang 3, Platform & UI)

### Status
- **Fase 1 (Minggu 1–4) SELESAI:** `docs/christ_business/approved/target_definitions.md` dan
  kontrak `contracts/K-06` s/d `K-11` sudah ada dan **sudah dibekukan (INTG-v1.0)**.
  Micro-task 1 (tabel `dec.action_catalogue` + test-nya) juga sudah dikerjakan secara lokal.
- **Sekarang: FASE 2 (Minggu 5–8)** — Policy Engine, Next-Best-Action (NBA), Nudge Generator,
  Safety Scanner. Semuanya di `services/decision/`.

---

## 2. ATURAN ISOLASI (paling penting — jangan dilanggar)

Tujuan: commit Christ **100% terisolasi** supaya `push` / `merge` tidak menimbulkan konflik.

### ✅ BOLEH dibuat/diubah (milik Christ)
| Path | Isi |
|---|---|
| `services/decision/**` | seluruh logika Decisioning (policy, nba, nudge, campaign, simulator, measurement, attribution, forecasting) |
| `tests/decision/**` | unit test Pytest untuk modul di atas |
| `contracts/**` | skema JSON K-06…K-11 (**sudah beku — lihat aturan perubahan di §5**) |
| `docs/christ_business/**` | dokumen bisnis & log pekerjaan (termasuk `reference/fase2.md`) |

### ⛔ DILARANG KERAS menyentuh (baca pun boleh, ubah tidak)
- Milik **James**: `api/`, `worker/`, `web/`, `migrations/`, `docs/james_platform/`,
  `tests/security/`, `tests/worker/`, `tests/integration/`, `tests/test_james_*.py`
- Milik **Moses**: `generator/`, `fixtures/`, `services/data/`, `docs/moses_data_ai/`, `tests/data/`
- File bersama/root: `requirements.txt`, `requirements-dev.txt`, `pyproject.toml`, `Makefile`,
  `docker-compose.yml`, `Dockerfile.*`, `alembic.ini`, `.github/**`, `.gitignore`, `README.md`,
  `services/__init__.py`, `services/common/**`

### Aturan Git
- **Jangan menjalankan** `git push`, `git merge`, `git rebase`, `git reset --hard`, `git stash`,
  atau `git checkout <branch-lain> -- <file>`. Semua operasi git dilakukan **Christ sendiri**.
  (Pada Micro-task 1, mengambil file James via `git checkout origin/... -- <file>` membuat file
  milik James ikut masuk ke branch Christ — itu yang harus dihindari.)
- Boleh hanya perintah baca: `git status`, `git diff`, `git diff --name-only`, `git log`.
- **Wajib sebelum menyatakan satu tugas selesai**, jalankan `git status --short` dan pastikan
  **semua** path yang berubah ada di daftar ✅ di atas. Salin hasilnya ke `fase2.md`.
  Jika ada path di luar daftar → **BERHENTI**, jangan lanjut, laporkan ke Christ.
- **Jangan menambah dependency baru.** Fase 2 hanya memakai Python standard library (+ `pytest`
  untuk test). Jangan edit `requirements*.txt` atau `pyproject.toml`.
- Kalau sebuah fitur butuh perubahan di `api/`, `worker/`, `migrations/`, dll., **jangan lakukan**.
  Cukup sediakan fungsi/kelas di `services/decision/` dan tulis di `fase2.md` bagian
  "Catatan untuk James" bagaimana James seharusnya meng-import-nya. James yang akan memanggilnya
  (mis. `from services.decision.nba.engine import NBAEngine`).

---

## 3. ATURAN PELAPORAN (wajib di setiap pengerjaan)

Setiap kali selesai mengerjakan satu micro-task, **tambahkan satu entri baru** di
`docs/christ_business/reference/fase2.md` (append di bagian bawah, jangan hapus entri lama).
Entri wajib memuat, dengan bahasa awam yang bisa dipahami Christ:

1. **Judul & Minggu** (mis. "Minggu 6 — Micro-task 6.1: ev_calculator.py")
2. **Apa yang dilakukan** (1–3 kalimat)
3. **Daftar file** — untuk setiap file: path lengkap, status (**DIBUAT** / **DIUBAH**), dan
   **apa yang ditulis di dalamnya** (fungsi/kelas apa, tujuannya)
4. **Folder mana** yang disentuh
5. **Perintah test** yang dijalankan + ringkasan hasilnya (jumlah passed/failed)
6. **Hasil `git status --short`** (bukti isolasi)
7. **Kendala / keputusan / hal yang perlu ditanyakan ke Christ**
8. **Catatan untuk James** (jika ada fungsi yang akan dipakai James)

Format lengkap ada di template `fase2.md`. **Tidak ada micro-task yang dianggap selesai
sebelum entri ini ditulis.**

---

## 4. KONDISI REPO SAAT INI (snapshot dari branch `main`)

> ⚠️ Ini snapshot. **Langkah 0 kamu: verifikasi sendiri ke working tree**
> (`ls`, baca file-nya, jalankan test) sebelum percaya pada tabel ini.

### Sudah ada di `services/decision/`
| File | Status | Catatan |
|---|---|---|
| `policy/fatigue.py` (±167 baris) | Ada | Frequency cap 2 kontak / 14 hari. Status `FREQ_CAP_OK` / `FREQ_CAP_SUPPRESSED`. Pengecualian: `COMPLAINT_RESOLUTION`, `SERVICE_REMINDER`. |
| `policy/suppression.py` (±236 baris) | Ada | Status `OPT_OUT_SUPPRESSED`, `COMPLAINT_SUPPRESSED`. Enum `ComplaintStatus.OPEN_SEVERE = "OPEN_SEVERE_COMPLAINT"`. |
| `nba/catalogue.py` (±366 baris) | Ada | 11 aksi (`ACTION_CATALOGUE`), `get_action()`, kategori berbahasa Indonesia — **selaras dengan K-06**. |
| `nba/engine.py` (±638 baris) | Ada | Kelas `NBAEngine` dengan method publik `evaluate(...)` → `NBAResult`. EV, kandidat, dan cek kelayakan masih **private method di dalam engine.py**. |
| `nudge/`, `campaign/`, `simulator/`, `measurement/`, `attribution/`, `forecasting/` | **Kosong** (hanya `__init__.py`) | Belum dikerjakan. |

### Test yang sudah ada
- `docs/christ_business/reference/test/` → `test_catalogue.py`, `test_engine.py`,
  `test_fatigue.py`, `test_suppression.py`, `conftest.py` — **107 test, semuanya lulus**.
  Ini **regression guard**: **jangan diedit, jangan dipindah, jangan dihapus**, dan harus
  tetap hijau setelah setiap perubahan kamu.
- `tests/decision/` **belum ada** → dibuat di Fase 2 untuk test baru.

### Selisih antara rencana (Panduan) dan kode yang ada — harus ditangani
| # | Rencana di Panduan | Kondisi kode | Tindakan di Fase 2 |
|---|---|---|---|
| G1 | Minggu 6: `nba/evaluator.py` & `nba/ev_calculator.py` | Belum ada; logika di dalam `engine.py` | Ekstrak ke 2 modul baru (refactor **tanpa mengubah perilaku**) |
| G2 | Minggu 7: `NBAEngine.decide()` | Hanya ada `evaluate()` | Tambah `decide()` yang membungkus `evaluate()`, **pertahankan** `evaluate()` |
| G3 | Minggu 7: `degraded_input = True` + nilai default konservatif | Skor kedaluwarsa hanya di-reset ke 0.0; tanpa flag | Tambah flag & penanganan skor `None`/belum dihitung |
| G4 | Minggu 7: output sesuai K-07 (`decision_id`, `checks[]`, `rationale_text`, `correlation_id`) | `NBAResult` belum berbentuk K-07 | Tambah konversi ke bentuk K-07 |
| G5 | Minggu 5: reason code `EXCL_OPEN_SEVERE_COMPLAINT` | Kode memakai status `COMPLAINT_SUPPRESSED` | Tambah field `reason_code` **bersifat aditif** — status lama JANGAN diubah |
| G6 | Minggu 8: `nudge/generator.py`, `nudge/safety.py` | Belum ada | Bangun dari nol |

---

## 5. SUMBER KEBENARAN (urutan prioritas jika ada konflik)

1. `Requirement_Capstone.md` (FRD/TRD) → `docs/christ_business/reference/Requirement_Capstone.md`
   *(Christ akan menaruhnya di sana. Jika file ini TIDAK ada saat kamu mulai → hentikan dan
   minta Christ menambahkannya; jangan menebak isi FRD/TRD.)*
2. `contracts/K-06 … K-11` — kontrak INTG-v1.0 yang **sudah dibekukan**.
   **Jangan ubah isi kontrak.** Jika kode tidak bisa dipenuhi tanpa mengubah kontrak → berhenti,
   tulis di `fase2.md`, tanya Christ (perubahan kontrak butuh persetujuan tim/dosen).
3. `docs/christ_business/approved/target_definitions.md`
4. `docs/christ_business/reference/Panduan_Kerja_Christ.md` (roadmap Minggu 1–16)
5. Kode & test yang sudah ada.

### Konstanta bisnis (dari `target_definitions.md` — pakai konsisten, jangan hardcode ulang)
```python
FREQ_CAP_MAX_CONTACTS = 2      # maks kontak komersial per rolling window
FREQ_CAP_WINDOW_DAYS = 14
SCORE_VALIDITY_DAYS = 30       # masa berlaku skor AI
PREDICTION_HORIZON_DAYS = 90   # jendela outcome label churn: 90 hari KE DEPAN setelah prediction_date
# Risk band churn: LOW <0.30 | MEDIUM 0.30–0.60 | HIGH 0.60–0.80 | VERY_HIGH >=0.80
```
> **Keputusan tim (target_definitions v1.2):** `min_ev_threshold` default **Rp 1.000** (alasan NO_ACTION: `BELOW_MIN_EV`);
> `SERVICE_REMINDER` hanya untuk ACTIVE/LOYAL dengan `days_until_replenishment <= 7` (data belum ada → aksi tidak aktif);
> K-08 punya `control_holdout_ratio` (default 0.10) dan `random_seed` (wajib bila holdout diisi).
>
> **Pembaruan Fase 1 (target_definitions v1.1):** definisi churn lama (180 hari ke belakang) dicabut;
> `CHURN_DEFINITION_DAYS` sudah dihapus. Label churn = tidak ada transaksi / kunjungan / perpanjangan
> membership dalam 90 hari ke depan. Angka 180 hari hanya dipakai pada lifecycle `CHURNED`.
> Rincian koreksi ada di `docs/christ_business/reference/fase1.md`. Matriks segmen→aksi (9 segmen) ada di
> `target_definitions.md` §3.1 dan **dikunci oleh test** `tests/decision/test_lifecycle_matrix.py`.
> Consent dari data nyata (K-10) WAJIB lewat `CustomerConsent.from_k10(...)`: status UNKNOWN / EXPIRED /
> kanal tidak tercantum = BLOCKED.
Prinsip utama sistem: **"Skor tinggi bukan izin."** Suppression (opt-out, komplain berat aktif)
**mutlak** — tidak ada skor AI/CLV yang boleh meng-override. Jika ragu → `NO_ACTION`.

---

## 6. RINCIAN TUGAS FASE 2

Kerjakan **berurutan, satu micro-task per giliran**. Setelah tiap micro-task: jalankan test,
tulis entri `fase2.md`, lalu **berhenti dan minta Christ konfirmasi** sebelum lanjut.

### Langkah 0 — Audit (sebelum coding)
- Baca: file ini, `Panduan_Kerja_Christ.md`, `target_definitions.md`, `contracts/K-06` & `K-07`,
  lalu `services/decision/**` yang sudah ada.
- Jalankan: `python -m pytest docs/christ_business/reference/test -q` → harus 107 passed.
- Tulis entri "Langkah 0 — Audit" di `fase2.md`: apa yang kamu temukan, apakah tabel §4 akurat.
- Cek nama file test agar unik: `find tests docs -name "test_*.py"`.

### Minggu 5 — Policy Engine
**File:** `services/decision/policy/fatigue.py`, `services/decision/policy/suppression.py`
(sudah ada — **perluas, jangan tulis ulang**)
- Tambah field `reason_code` (default `""`) pada hasil cek, bernilai `FREQ_CAP_SUPPRESSED` atau
  `EXCL_OPEN_SEVERE_COMPLAINT` bila relevan. Field `status` yang lama **tidak boleh berubah**.
- Test baru: `tests/decision/test_policy.py` (mis. tepat 2 kontak = suppressed? tepat 14 hari?
  komplain `RESOLVED` tidak memblokir; `COMPLAINT_RESOLUTION` tetap lolos).
- **Selesai jika:** audiens bisa difilter dan alasan penekanan dikembalikan dengan benar.

### Minggu 6 — NBA Evaluator & EV Calculator
**File baru:** `services/decision/nba/evaluator.py`, `services/decision/nba/ev_calculator.py`
- `ev_calculator.py`: fungsi murni (pure function), tanpa I/O:
  `EV = Propensity × ExpectedRevenueContribution × ActionWeight − IncentiveCost`.
  Validasi input (propensity 0–1, tidak negatif), hasil dibulatkan konsisten, deterministik.
- `evaluator.py`: evaluasi **5 masukan independen** secara terpisah, masing-masing mengembalikan
  hasil lolos/gagal + alasan, **dengan pemetaan Requirement_Capstone Bab 3**:
  (1) Skor Prediksi ML; (2) Business Eligibility — termasuk keluhan `OPEN_SEVERE_COMPLAINT` aktif;
  (3) Customer Consent (opt-out); (4) Contact Policy — frequency cap saja; (5) Product Suitability.
- Refactor `engine.py` agar memanggil dua modul ini. **Perilaku harus identik** — 107 test
  referensi tetap hijau.
- Test baru: `tests/decision/test_ev_calculator.py`, `tests/decision/test_evaluator.py`.
- **Selesai jika:** skor EV kandidat bisa dihitung & 5 gerbang bisa dievaluasi terpisah.

### Minggu 7 — NBA Engine Core & Fallback NO_ACTION
**File:** `services/decision/nba/engine.py`
- Tambah `NBAEngine.decide(...)` → mengembalikan rekaman keputusan yang bentuknya
  **mengikuti `contracts/K-07_decision_record.json`** (baca schema-nya; field wajib:
  `decision_id`, `customer_id`, `selected_action_id`, `expected_value`, `candidates`, `checks`,
  `rationale_text`, `correlation_id`). `decision_id` dan waktu harus bisa di-inject agar test
  deterministik.
- **Degraded input:** skor kedaluwarsa atau belum dihitung → pakai default konservatif dan set
  `degraded_input = True` (tampil di hasil + `rationale_text`).
- **Fallback NO_ACTION:** semua kandidat `EV < ev_min_threshold` atau gagal gerbang kebijakan →
  `NO_ACTION` dengan `rationale_text` yang jelas. (Parameter lama `min_ev_threshold` tetap
  didukung; `ev_min_threshold` boleh jadi alias.)
- `evaluate()` yang lama **dipertahankan**.
- Alasan NO_ACTION menurut Requirement Bab 4: Opt-Out, Frequency Cap tercapai, atau
  `ALL_CANDIDATES_BLOCKED`. Jangan menambah kode alasan lain yang tidak ada di dokumen.
- Keputusan `decide()` harus sama dengan `evaluate()`; jangan menambah aturan yang tidak ada
  di Requirement/Panduan.
- Test baru: `tests/decision/test_nba_engine.py`. Jika perlu memvalidasi ke JSON Schema, pakai
  `pytest.importorskip("jsonschema")` (jangan menambah dependency).
- **Selesai jika:** `decide()` menghasilkan aksi terbaik atau `NO_ACTION` lengkap dengan `rationale_text`.

### Minggu 8 — Nudge Generator & Safety Scanner
**File baru:** `services/decision/nudge/generator.py`, `services/decision/nudge/safety.py`
- `generator.py`: draf pesan memakai substitusi **whitelist variabel saja**:
  `first_name`, `preferred_branch`, `points_balance`, `offer_validity`, diambil dari Fact Package
  (lihat `required_fact_package` per aksi di `catalogue.py`/K-06). Variabel di luar whitelist
  atau fakta yang hilang → **jangan dikarang**; kembalikan status gagal yang jelas.
  Setiap draf berstatus **`GENERATED_DRAFT`** dan butuh **persetujuan manusia** sebelum dirilis
  (jangan pernah menandai pesan sebagai "terkirim/approved" otomatis).
- `safety.py`: scanner blacklist regex untuk klaim terlarang — klaim medis, jaminan 100%, diskon
  di atas pagu. Draf yang melanggar → `MESSAGE_BLOCKED_BY_GUARDRAIL`. Pagu diskon adalah **keputusan tim** (bukan dari Requirement_Capstone):
  `MAX_DISCOUNT_PERCENT = 30.0`, batas per band (Tanpa Insentif 0%, Rendah <= 10%, Sedang <= 20%, Tinggi <= 30%),
  pelanggaran → draf diblokir + penanda `INCENTIVE_ESCALATED` (wajib dieskalasi ke Business Approver; LLM/AI tidak
  boleh menentukan besaran diskon). Daftar kata terlarang juga keputusan tim (`FORBIDDEN_TERMS`). **Jangan mengubah angka/daftar tanpa keputusan baru.**
- Semua offline, tanpa panggilan jaringan, tanpa LLM/API eksternal.
- Test baru: `tests/decision/test_nudge_generator.py`, `tests/decision/test_safety_scanner.py`.
- **Selesai jika:** draf berisi kata terlarang otomatis diblokir.

---

## 7. ATURAN KODE & TEST

- Python **3.12**, `from __future__ import annotations`, type hints lengkap, dataclass untuk struktur data.
- Gaya mengikuti repo: **black** (line length 88) dan **ruff** (aturan E, F, I; E501 diabaikan).
  Setelah menulis, jalankan:
  `black services/decision tests/decision` lalu `ruff check services/decision tests/decision`.
  **Jangan** menjalankan black/ruff pada folder milik orang lain.
- Fungsi bisnis harus **deterministik** dan **tanpa efek samping** (tanpa jaringan, tanpa tulis DB,
  tanpa baca file acak). Waktu & ID acak harus bisa di-inject.
- Jangan import dari `api/`, `worker/`, atau `services/data/` (arah ketergantungan: mereka yang
  meng-import kita, bukan sebaliknya).
- Jangan memakai data pelanggan nyata; data test sintetis saja.
- Perintah test:
  - Test baru: `python -m pytest tests/decision -v`
  - Regression: `python -m pytest docs/christ_business/reference/test -q` (harus tetap 107 passed)
- Test harus mencakup: kasus normal, batas (boundary), input rusak/kosong, dan kasus "skor tinggi
  tapi diblokir kebijakan → NO_ACTION".

---

### Pemeriksaan CI WAJIB sebelum menyatakan tugas selesai
CI GitHub memakai **Python 3.11** dan menjalankan (berurutan):
```
ruff check .
mypy services api worker --ignore-missing-imports
black --check api worker migrations ...        # daftar tetap, tidak mencakup services/
pytest tests/security/test_allowlist.py -v
pytest -v
```
Aturan agar tidak gagal di CI:
- **Jangan melewatkan `Optional[X]` ke parameter bertipe `X`.** `get_action()` mengembalikan `Optional[Action]`;
  untuk aksi inti yang wajib ada (`NO_ACTION`, `COMPLAINT_RESOLUTION`) pakai `require_action()`.
  Dilarang menutupi error dengan `# type: ignore` atau `assert` kosong.
- Jalankan `mypy services api worker --ignore-missing-imports` (mypy `>=1.10,<2.0`) dan `ruff check .` sebelum selesai.
- **CI memeriksa format seluruh repo (`black --check`, black `>=24.0,<26.0`).** Setelah menulis/mengubah kode, jalankan
  `black services/decision tests/decision` (HANYA folder Christ; jangan `black .`), lalu pastikan `black --check services/decision tests/decision` lolos.
  Setiap file harus diakhiri tepat SATU newline. Gunakan black dari `requirements-dev.txt`, bukan versi lain.
- Jangan memakai sintaks khusus Python 3.12 (CI 3.11).
- Catat hasil mypy dan ruff di `fase2.md` bersama hasil test.

---

## 8. MASALAH YANG SUDAH DIKETAHUI — JANGAN DIPERBAIKI SENDIRI, LAPORKAN KE CHRIST

1. **Migrasi `0007_create_action_catalogue` (Micro-task 1) berpotensi bentrok dengan `main`.**
   Di `main` sudah ada `0007_pipeline_runs` (down_revision `0006_governance_workflows`), lalu
   0008–0010. Migrasi Christ juga bercabang dari `0006_governance_workflows` → Alembic akan
   mendeteksi **dua head** setelah merge. Folder `migrations/` dan `api/models.py` adalah milik
   James. **Jangan sentuh.** Penyelesaian harus dikoordinasikan Christ dengan James.
2. **ID aksi di seed migrasi Micro-task 1 berbeda dengan K-06 & `catalogue.py`.**
   Seed memakai mis. `RETENTION_CALL_OFFER`, sedangkan kontrak beku K-06 memakai
   `RETENTION_OUTREACH`, `CROSS_SELL`, `UPSELL`, `RENEWAL_REMINDER`, `SERVICE_REMINDER`,
   `EDUCATION`, `LOYALTY_REWARD`, `WIN_BACK_OFFER`, `RELATIONSHIP_MANAGER_CONTACT`,
   `COMPLAINT_RESOLUTION`, `NO_ACTION`. **Untuk Fase 2, K-06 + `catalogue.py` adalah acuan.**
   Mesin Fase 2 memakai katalog in-memory, **tidak bergantung** pada tabel database.
3. Reason code `EXCL_OPEN_SEVERE_COMPLAINT` (Panduan) vs status `COMPLAINT_SUPPRESSED` (kode) —
   ditangani lewat field `reason_code` aditif (lihat Minggu 5).

Jika kamu menemukan masalah lain di luar folder Christ: **catat di `fase2.md` → "Kendala", lalu tanya Christ.**

---

## 9. ALUR KERJA PER GILIRAN (ringkas)

1. Konfirmasi micro-task yang dikerjakan & rencana singkat (file apa, di folder mana).
2. Tulis kode + test **hanya** di path ✅.
3. Jalankan black, ruff, test baru, dan test regression.
4. Jalankan `git status --short` → pastikan tidak ada path terlarang.
5. Tulis entri di `docs/christ_business/reference/fase2.md`.
6. Ringkas ke Christ dalam Bahasa Indonesia, lalu **tunggu konfirmasi** sebelum micro-task berikutnya.

## 10. DEFINITION OF DONE — FASE 2

- [ ] Policy Engine mengembalikan `FREQ_CAP_SUPPRESSED` dan `EXCL_OPEN_SEVERE_COMPLAINT` dengan benar
- [ ] `ev_calculator.py` & `evaluator.py` ada, 5 gerbang dievaluasi terpisah
- [ ] `NBAEngine.decide()` menghasilkan rekaman bentuk K-07, termasuk `degraded_input` & fallback `NO_ACTION`
- [ ] Nudge Generator + Safety Scanner memblokir klaim terlarang; semua draf `GENERATED_DRAFT`
- [ ] `tests/decision/` hijau, 107 test referensi tetap hijau
- [ ] black & ruff bersih pada `services/decision` dan `tests/decision`
- [ ] `git status` hanya menampilkan path milik Christ
- [ ] `fase2.md` berisi entri lengkap untuk setiap micro-task
