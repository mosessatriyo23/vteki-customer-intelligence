# Log Evaluasi FASE 1 — Christ Jevicto (Orang 2)

- **Tanggal evaluasi:** 2026-11-07
- **Lingkup:** Minggu 1–4 (`target_definitions.md`, kontrak K-06 s/d K-11) + Micro-task 1 (`dec.action_catalogue`).
- **Sumber pembanding:** `Panduan_Kerja_Christ.md` (Minggu 1–4), `Requirement_Capstone.md`, `contracts/business_events.md`,
  kode Moses (`services/data/models/labels.py`, `services/data/segmentation/snapshot.py`), dan kode `services/decision/`.
- **Metode:** setiap temuan dibuktikan dengan membaca teks sumber dan/atau menjalankan kode/validasi JSON Schema. Tidak ada angka atau aturan yang dikarang.
- **Folder yang disentuh:** `docs/christ_business/`, `contracts/`, `tests/decision/` (semuanya milik Christ).

## Ringkasan

| Hasil | Jumlah |
|---|---|
| Kesalahan ditemukan **dan diperbaiki** | 6 |
| Ditemukan, butuh keputusan / di luar area Christ | 8 |
| Sudah sesuai (diperiksa) | 7 |

---

## A. Ditemukan salah dan SUDAH DIPERBAIKI

| # | Berkas | Temuan | Bukti | Perbaikan |
|---|---|---|---|---|
| A1 | `target_definitions.md` §1.1 | **Definisi churn salah arah.** v1.0: tanpa transaksi 180 hari ke **belakang**, plus syarat "tidak diprediksi aktif 90 hari ke depan" (sirkular). Itu bukan target prediksi. Panduan Minggu 1: window **90 hari pasca** `prediction_date`. Pipeline Moses sudah memakai jendela 90 hari ke depan. | Panduan Min. 1; `business_events.md` (*Model labels*); `labels.py`: `churn90 = int(not future)` dengan `future` = transaksi di (cutoff, cutoff+90]. | Ditulis ulang (v1.1): cohort, jendela outcome 90 hari ke depan, churn = tidak ada negation event, label tidak lengkap = null. |
| A2 | `target_definitions.md` §1.1 | **Churn negation events tidak didefinisikan** (Panduan Minggu 1: transaksi POS ≥ 1, kunjungan fisik terverifikasi, perpanjangan membership). | Teks v1.0. | 3 negation events dicantumkan. |
| A3 | `target_definitions.md` §2.1 | `Retention_Factor` "default 0.7 untuk Active" **tanpa sumber**; Requirement hanya menyebut nama variabel. | Requirement Bab 2.2. | Angka dicabut, dicatat sebagai asumsi tanpa sumber. |
| A4 | `target_definitions.md` §3 | Panduan Minggu 1 meminta **matriks alokasi perlakuan untuk 9 segmen**; v1.0 hanya 7 tahap tanpa matriks. Moses punya 9 label (`OCCASIONAL`, `NEVER_TRANSACTED` tambahan). | `snapshot.py`; Panduan Min. 1. | Ditambah 2 label (ditandai *usulan*), §3.1 matriks 9 segmen dari Requirement Bab 4. Segmen tanpa aturan ditulis **"Belum ditetapkan"**. |
| A5 | `target_definitions.md` §4.2 + Lampiran | Reason code `EXCL_OPEN_SEVERE_COMPLAINT` (Panduan) tidak tertulis; keluhan aktif tidak dipetakan ke 5 masukan Bab 3; konstanta `CHURN_DEFINITION_DAYS = 180` menyesatkan. | Panduan Min. 1; Requirement Bab 3 baris 2. | Reason code, penempatan masukan, dan butir konfirmasi cakupan opt-out ditambahkan; konstanta dihapus (tidak dipakai di kode mana pun). |
| A6 | `K-06`, `K-07`, `K-10` | Lihat tabel kontrak di bawah. | Dokumen uji di `tests/decision/test_contracts.py`. | Skema diperbaiki, 38 test baru. |

### Pembaruan 2026-11-09 (keputusan tim, lihat `fase2.md` Revisi 5)

| Berkas | Perubahan |
|---|---|
| `K-08` | Ditambah **aditif** `control_holdout_ratio` (default 0.10) dan `random_seed` (wajib bila holdout diisi); `ab_test_ratio` default 50 → 90. Dokumen lama tetap valid; `exposure_window` dan `status` tidak berubah. |
| `K-07` | `no_action_reason` mendapat nilai `BELOW_MIN_EV`. |
| `target_definitions.md` | v1.2: matriks §3.1 (SERVICE_REMINDER), konstanta keputusan tim, riwayat revisi. |

Dengan ini hambatan #1 (K-08 tanpa holdout) pada daftar "sebelum Fase 3" **selesai**.

### Perbaikan kontrak (semuanya relaksasi/penguatan aman, tidak mengubah field wajib Panduan)

| Kontrak | Cacat (dibuktikan dengan dokumen uji yang lolos validasi) | Perbaikan |
|---|---|---|
| K-06 | `required_fact_package` `minItems: 1` membuat **NO_ACTION tidak mungkin valid**. Sebaliknya, NO_ACTION dengan kanal `email` + insentif `Band Sedang` **lolos**, padahal Requirement Bab 4 = "Tanpa Kanal / Tanpa Insentif". | `if/then/else`: NO_ACTION wajib tanpa kanal, `Tanpa Insentif`, fact package kosong; aksi lain wajib ≥ 1 fact. |
| K-10 | Channel `UNKNOWN` dengan `effective_permission: ALLOWED` **lolos**; `most_restrictive_wins: false` **lolos** — keduanya melanggar Panduan Minggu 3 (unknown/expired = blocked; paling restriktif menang). | Status ≠ `OPT_IN` ⇒ `opt_in=false` & `BLOCKED`; `most_restrictive_wins` `const: true`. |
| K-10 | `customer_id` hanya `string` sedangkan K-07/K-09 menerima `string` atau `integer` — consent untuk pelanggan ber-ID integer ditolak. | `["string","integer"]`. |
| K-07 | Properti yang dipakai `decide()` (`degraded_input`, `no_action_reason`) tidak terdaftar. | Ditambahkan sebagai properti opsional (non-breaking). `no_action_reason` dibatasi ke 3 kode Requirement Bab 4. |

---

## B. Ditemukan, BELUM bisa diperbaiki (butuh keputusan atau di luar area Christ)

| # | Masalah | Pemilik / tindakan |
|---|---|---|
| B1 | **Persetujuan v1.1:** `target_definitions.md` v1.1 belum disetujui; kolom "Disetujui oleh" dikosongkan (README folder mensyaratkan approver/tanggal/versi). Tidak ada bukti persetujuan v1.0 di repo. | Christ: isi penyetuju. Dosen/Mentor: setujui v1.1. |
| B2 | **Requirement tidak konsisten:** Bab 2.1 "180 hari ke depan" vs horizon 90 hari. v1.1 memilih 90 (Panduan + implementasi). | Konfirmasi Dosen/Mentor. |
| B3 | **Kode Moses vs doc lifecycle:** `NEW` di kode = tenure ≤ 30 hari saja (doc juga mensyaratkan transaksi ≤ 2x); `AT_RISK`/`DORMANT`/`CHURNED` di kode hanya berbasis recency (doc juga mensyaratkan kondisi membership). Aturan Requirement sendiri tidak eksklusif/lengkap. | Moses + Christ: sepakati urutan prioritas (dicatat di §3). |
| B4 | **Label churn Moses:** `services/data/models/labels.py` hanya menghitung `transactions.csv`; perpanjangan membership (`membership_events.csv`) tidak terlihat dihitung, padahal `business_events.md` dan Panduan menyebutnya sebagai negation event. | Moses: konfirmasi. |
| B5 | **Target CLV:** kode Moses melatih `clv90` = pendapatan 90 hari ke depan (`actual_revenue`); kontrak mendefinisikan CLV = historis 12 bulan + proyeksi 12 bulan, **Gross Revenue**. Belum jelas apakah `actual_revenue` = gross. | Moses: konfirmasi. |
| B6 | **Cakupan opt-out** (global vs per kanal) ambigu antara §4.2 v1.0, Requirement Bab 3, dan K-10. Ditandai [PERLU KONFIRMASI] di doc. | Christ/tim. |
| B7 | **Micro-task 1 — migrasi `0007_create_action_catalogue`:** bentrok dengan `0007_pipeline_runs` di `main` (dua head Alembic). Berkas yang diubah (`migrations/`, `api/models.py`) milik James; penjelasan Micro-task 1 menulis migrasi itu "mencegah konflik percabangan git" — tidak benar sekarang. | Christ + James sebelum push. |
| B8 | **Micro-task 1 — isi tabel tidak sama dengan K-06:** seed memakai ID `RETENTION_CALL_OFFER` dll (K-06: `RETENTION_OUTREACH` dst); constraint DB memakai kategori Inggris (`RETENTION`, `GROWTH`, …) dan band `NONE/LOW/MEDIUM/HIGH` (K-06: kategori Indonesia dan 6 band termasuk `Hadiah / Poin Loyalitas`, `Diskon Berbatas Waktu`); NO_ACTION memakai kanal `["NONE"]` (K-06: kosong). Tiga representasi (K-06, `catalogue.py`, DB) tidak seragam. | Christ + James: tentukan satu acuan (K-06 sudah dibeku). |

## C. Dibawa ke koreksi Fase 2 (terbukti saat evaluasi Fase 1)

| # | Masalah | Bukti |
|---|---|---|
| C-1 | `catalogue.py` **tidak punya `required_fact_package`** (wajib K-06): 11 dari 11 aksi tidak valid terhadap K-06. | Test `test_catalogue_documents_validate_against_k06` (ditandai `xfail strict`; hapus xfail setelah field ditambahkan). |
| C-2 | `CustomerConsent` default `*_opt_in = True`: consent yang tidak diketahui diperlakukan sebagai diizinkan, bertentangan dengan K-10 / Panduan Minggu 3 (unknown/expired = blocked). | `services/decision/policy/suppression.py` baris dataclass. |

## D. Sudah sesuai (diperiksa)

- Semua 6 kontrak K-06…K-11 adalah JSON Schema Draft-07 yang valid dan `$id` sesuai nama berkas.
- Field wajib K-06 dan K-07 sama dengan Panduan Minggu 2; enum `action_id` K-06 = K-07 = `catalogue.py` (11 aksi); nilai kategori/band/kanal di `catalogue.py` berada di dalam enum K-06.
- K-08: `conversion_window_days = 30`, `adjustment_window_days = 14` (Panduan Minggu 3).
- K-09: tipe konversi BOOKING/PURCHASE/MEMBERSHIP_RENEWAL/UPGRADE dan transisi Gross→Net (Panduan Minggu 4).
- K-11: `X-Correlation-ID` wajib; pola correlation id identik di K-07…K-11.
- Lifecycle (batas 91/180/181/365), tier CLV (200rb/500rb/1jt), risk band, fatigue 2/14, validitas skor 30 hari: doc = Requirement = kode.
- Tier CLV `GOLD` = "Tinggi", `SILVER` = "Sedang" (target_definitions §2.2). Temuan lama bahwa RETENTION_OUTREACH menolak `SILVER` ternyata **bukan bug** dan ditarik.

## Verifikasi

- `python -m pytest tests/decision/test_contracts.py -q` → 38 passed, 1 xfailed (xfail = C-1, disengaja).
- Seluruh suite repo (di luar `tests/integration`) → 452 passed, 1 xfailed.
- Tidak ada kode lain di repo yang memuat/memvalidasi `contracts/*.json`, sehingga perubahan kontrak tidak memengaruhi `api/`, `worker/`, atau `services/data/`.
