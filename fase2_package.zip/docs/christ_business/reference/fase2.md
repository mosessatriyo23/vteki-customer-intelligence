# Log Pengerjaan FASE 2 — Christ Jevicto (Orang 2)

- **Branch:** `71230997-Christ-Jevicto-2`
- **Lingkup:** Minggu 5–8 (Policy Engine, NBA, Nudge Generator, Safety Scanner)
- **Folder kerja yang dipakai:** `services/decision/`, `tests/decision/`, `docs/christ_business/`
- **Folder milik orang lain yang disentuh:** **TIDAK ADA** (`api/`, `worker/`, `migrations/`, `web/`, `generator/`, `fixtures/`, `services/data/`, `contracts/` tidak diubah)
- **Sumber acuan yang dipakai:** `Requirement_Capstone.md` (Bab 3–5), `Panduan_Kerja_Christ.md`, `contracts/K-06` & `K-07`, `target_definitions.md`.
  Setiap aturan di bawah ditandai sumbernya. Hal yang **tidak tertulis di sumber mana pun** tidak diisi dengan angka/aturan karangan — dicatat di bagian "Belum bisa diputuskan".

## Ringkasan Progres

| Micro-task | Minggu | Status | Test baru |
|---|---|---|---|
| Langkah 0 — Audit | — | ✅ | — |
| Policy Engine (`reason_code`) | 5 | ✅ | 20 (`test_policy.py`) |
| `ev_calculator.py` + `evaluator.py` | 6 | ✅ | 54 (`test_ev_calculator.py` 20, `test_evaluator.py` 34) |
| `NBAEngine.decide()` + degraded + K-07 | 7 | ✅ | 55 (`test_nba_engine.py`) |
| `nudge/generator.py` + `nudge/safety.py` | 8 | ✅ | 70 (`test_nudge_generator.py` 35, `test_safety_scanner.py` 35) |
| **Revisi 1 — evaluasi terhadap Requirement_Capstone.md** | 5–8 | ✅ | (lihat di bawah) |
| **Revisi 2 — koreksi akibat evaluasi Fase 1** (K-06, K-10, matriks segmen) | 5–8 | ✅ | 97 baru (lihat di bawah) |
| **Revisi 3 — perbaikan CI mypy** (`Action \| None`) | 7 | ✅ | 3 baru |
| **Revisi 4 — perbaikan CI format (black)** | 5–8 | ✅ | — |
| **Revisi 5 — keputusan tim: K-08 holdout, threshold, pagu, SERVICE_REMINDER** | 6–8 | ✅ | 70 baru |

**Total:** `tests/decision` = **369 passed**; regression referensi = **107 passed** (tidak ada test lama yang diubah); total 476.

---

## ENTRI PENGERJAAN

### [Langkah 0 — Audit]
Membaca `target_definitions.md`, K-06, K-07, dan seluruh `services/decision/`. Ditemukan `fatigue.py`, `suppression.py`, `catalogue.py`, `engine.py` sudah ada (107 test referensi lulus); belum ada `evaluator.py`, `ev_calculator.py`, `decide()`, flag `degraded_input`, dan `nudge/` kosong. Tidak ada file dibuat/diubah.

---

### [Minggu 5 — Policy Engine: field `reason_code`]
**Sumber:** Panduan Minggu 5 (checkpoint: `FREQ_CAP_SUPPRESSED`, `EXCL_OPEN_SEVERE_COMPLAINT`); Requirement Bab 3 baris 4 (`FREQ_CAP_SUPPRESSED`).

| Path | Status | Apa yang ditulis |
|---|---|---|
| `services/decision/policy/fatigue.py` | DIUBAH | `FatigueCheckResult.reason_code` (default `""`), diisi `FREQ_CAP_SUPPRESSED` saat terblokir. Import dirapikan. |
| `services/decision/policy/suppression.py` | DIUBAH | Konstanta `REASON_CODE_OPT_OUT`, `REASON_CODE_OPEN_SEVERE_COMPLAINT`; `SuppressionCheckResult.reason_code` = `OPT_OUT_SUPPRESSED` / `EXCL_OPEN_SEVERE_COMPLAINT`. `status` lama **tidak berubah**. |
| `tests/decision/test_policy.py` | DIBUAT | 20 test (batas 2 kontak, batas 14 hari, kontak non-komersial & `COMPLAINT_RESOLUTION`/`SERVICE_REMINDER` tidak dihitung, komplain non-severe/resolved tidak memblokir, opt-out lebih prioritas dari komplain, dll.). |

Catatan sumber: nama `EXCL_OPEN_SEVERE_COMPLAINT` berasal dari **Panduan**, bukan dari Requirement_Capstone (yang hanya menulis `OPEN_SEVERE_COMPLAINT` memblokir promosi).

---

### [Minggu 6 — Evaluator 5 gerbang & EV Calculator]
**Sumber:** Requirement Bab 3 (5 masukan) dan Bab 5 (rumus EV).

| Path | Status | Apa yang ditulis |
|---|---|---|
| `services/decision/nba/ev_calculator.py` | DIBUAT | `calculate_expected_value()` = `Propensity × ExpectedRevenue × ActionWeight − IncentiveCost` (+ validasi input, pembulatan 2 desimal), `get_propensity()`, `estimate_expected_revenue()`, `estimate_incentive_cost()`. Angka faktor revenue & biaya insentif **dipindahkan apa adanya dari engine.py awal** (bukan dari Requirement). |
| `services/decision/nba/evaluator.py` | DIBUAT | `GateResult` + 5 gerbang. **Pemetaan sesuai Bab 3:** (1) skor ML; (2) Business Eligibility **termasuk keluhan OPEN_SEVERE_COMPLAINT aktif**; (3) Consent = opt-out; (4) Contact Policy = **frequency cap saja**; (5) Product Suitability. Fungsi: `evaluate_ml_score_gate`, `evaluate_complaint_block`, `evaluate_business_eligibility_gate`, `evaluate_consent_gate`, `evaluate_contact_policy_gate`, `evaluate_product_suitability_gate`, `evaluate_five_gates`. |
| `services/decision/nba/engine.py` | DIUBAH | `_evaluate_candidates` memakai modul di atas; method privat lama jadi delegasi tipis; `ActionCandidate.blocked_gate` (aditif). |
| `tests/decision/test_ev_calculator.py` | DIBUAT | 20 test. |
| `tests/decision/test_evaluator.py` | DIBUAT | 34 test. |

Regression 107 test tetap lulus setelah refactor (perilaku `evaluate()` tidak berubah).

---

### [Minggu 7 — `NBAEngine.decide()`, degraded input, keluaran K-07]
**Sumber:** Panduan Minggu 7; Requirement Bab 3 baris 1, Bab 4 baris NO_ACTION, Bab 5 (ambang EV); kontrak K-07.

| Path | Status | Apa yang ditulis |
|---|---|---|
| `services/decision/nba/engine.py` | DIUBAH | `DecisionRecord` (+`to_dict()`), `NBAEngine.decide(...)`, alias `ev_min_threshold`, skor default saat `ai_scores=None`, `candidates[]` berperingkat, `checks[]`, `channel_selected`, dan `no_action_reason`. |
| `services/decision/nba/evaluator.py` | DIUBAH | `COMPLAINT_RESOLUTION` bukan kandidat EV biasa. |
| `tests/decision/test_nba_engine.py` | DIBUAT | 55 test, termasuk validasi `to_dict()` terhadap `contracts/K-07_decision_record.json` (6 skenario). |

**Perilaku `decide()` (semua bersumber):**
- Keputusan aksi **identik** dengan `evaluate()`. `decide()` hanya menambah: bentuk K-07, `degraded_input`, `no_action_reason`.
- Skor kedaluwarsa atau `None` → propensity default 0.0 dan `degraded_input=True` (Bab 3 baris 1 "menggunakan default"; Panduan Minggu 7 "menandai degraded_input = True").
- `no_action_reason` hanya diisi untuk tiga alasan yang disebut Bab 4 baris NO_ACTION: `OPT_OUT_SUPPRESSED`, `FREQ_CAP_SUPPRESSED`, `ALL_CANDIDATES_BLOCKED`. Untuk "EV < threshold" dokumen tidak memberi kode → `None` (tidak dikarang).
- Ambang EV: `EV < min_ev_threshold → NO_ACTION` (Bab 5).
- `checks[]` memakai pembagian Bab 3: `ML_SCORE_CHECK`, `CONSENT_CHECK`, `CONTACT_POLICY_CHECK` (frequency cap), `ELIGIBILITY_CHECK` (gagal dengan status `COMPLAINT_SUPPRESSED` bila ada komplain aktif; selain itu agregat kandidat), `SUITABILITY_CHECK`.

**Bug kode awal yang diperbaiki (kini terbukti oleh Requirement Bab 4 baris 2):** `COMPLAINT_RESOLUTION` ikut sebagai kandidat EV biasa (EV 0) sehingga bisa terpilih tanpa ada komplain. Bab 4: aksi ini dipicu "Keluhan aktif (status OPEN_SEVERE)". Sekarang hanya lewat jalur komplain aktif.

---

### [Minggu 8 — Nudge Generator & Safety Scanner]
**Sumber:** Panduan Minggu 8 (whitelist variabel, blacklist regex, `GENERATED_DRAFT`, `MESSAGE_BLOCKED_BY_GUARDRAIL`); Requirement Bab 3 baris 5 ("tanpa klaim medis").

| Path | Status | Apa yang ditulis |
|---|---|---|
| `services/decision/nudge/safety.py` | DIBUAT | `scan_message()`; aturan `MEDICAL_CLAIM`, `ABSOLUTE_GUARANTEE`, `DISCOUNT_ABOVE_CAP`, `UNRESOLVED_PLACEHOLDER`. **`MAX_DISCOUNT_PERCENT = None`** (pagu tidak tertulis di sumber mana pun) → **fail-closed**: selama pagu belum ditetapkan, setiap klaim diskon persentase diblokir. |
| `services/decision/nudge/generator.py` | DIBUAT | Whitelist 4 variabel, `TEMPLATES` 8 aksi, `generate_nudge()`, `approve_draft()`, `NudgeDraft`. Draf selalu `GENERATED_DRAFT` + butuh persetujuan manusia. |
| `tests/decision/test_safety_scanner.py` | DIBUAT | 35 test. |
| `tests/decision/test_nudge_generator.py` | DIBUAT | 35 test. |

Catatan sumber: daftar kata/regex klaim medis & jaminan adalah **daftar awal buatan saya** (Panduan hanya menyebut kategorinya). Teks template adalah **contoh** saya; sesuaikan dengan tone brand.

---

## REVISI 1 — Evaluasi ulang terhadap Requirement_Capstone.md

Dilakukan setelah `Requirement_Capstone.md` tersedia. Setiap temuan dibuktikan dengan membaca teks dokumen dan menjalankan kode.

### A. Ditemukan salah / tanpa dasar, SUDAH DIPERBAIKI

| # | Temuan | Sumber | Perbaikan |
|---|---|---|---|
| 1 | Keluhan aktif saya taruh di gerbang 4 (Contact Policy). Bab 3 menempatkannya di masukan 2 (Business Eligibility); masukan 4 hanya frequency cap. | Bab 3 baris 2 & 4 | `evaluate_contact_policy_gate(fatigue_result)` kini hanya frequency cap; keluhan masuk `evaluate_complaint_block` / gerbang 2. `checks[]` K-07 disesuaikan. |
| 2 | `decide()` tidak pernah menghasilkan alasan `ALL_CANDIDATES_BLOCKED`, padahal disebut sebagai salah satu pemicu NO_ACTION. | Bab 4 baris 1 | Field `no_action_reason` (+ teks `rationale_text`). |
| 3 | Aturan tambahan buatan saya: pada input terdegradasi, EV harus *lebih besar* dari threshold. Tidak ada di Requirement maupun Panduan; membuat `decide()` berbeda dari `evaluate()`. | — | **Dihapus.** `decide()` ≡ `evaluate()` + penanda. |
| 4 | `MAX_DISCOUNT_PERCENT = 30` adalah angka karangan. Requirement tidak memuat kata "pagu" maupun angka persen diskon. | Pencarian teks Requirement: 0 kemunculan "pagu"/"persen" | Diganti `None` + fail-closed (lihat Minggu 8). |
| 5 | Template `RENEWAL_REMINDER` memakai `{offer_validity}` sebagai tanggal akhir membership, dan `LOYALTY_REWARD` sebagai masa berlaku poin. Arti variabel itu "masa berlaku penawaran". | Panduan (nama whitelist) | Kalimat tanggal dihapus dari kedua template. |
| 6 | Test saya mengunci `SERVICE_REMINDER` terpilih untuk pelanggan `CHURNED` — perilaku yang tidak ada dasarnya. | Bab 4 baris 8 | Test dihapus. |

### B. Sudah sesuai dokumen (diperiksa)

- Rumus EV dan ambang `EV < min_ev_threshold → NO_ACTION` (Bab 5).
- Opt-out → NO_ACTION (Bab 3 baris 3); frequency cap → `FREQ_CAP_SUPPRESSED` (Bab 3 baris 4).
- Skor kedaluwarsa → default (Bab 3 baris 1).
- `COMPLAINT_RESOLUTION` hanya untuk keluhan aktif (Bab 4 baris 2).
- Aturan UPSELL (tenure ≥ 60), RENEWAL_REMINDER (≤ 15 hari), EDUCATION (New + Low), LOYALTY_REWARD (Loyal + CLV tinggi) di kode lama cocok dengan Bab 4.
- NO_ACTION tanpa kanal & tanpa insentif (Bab 4 baris 1).
- Larangan klaim medis (Bab 3 baris 5).

### C. BELUM bisa diputuskan — butuh keputusan Christ/tim (tidak saya karang)

| # | Masalah | Bukti |
|---|---|---|
| C1 | **CROSS_SELL**: Bab 4 mensyaratkan "belum memiliki produk di kategori bersebelahan" dan "Propensity Purchase Tinggi". Kode tidak memakai `purchased_categories` dan tidak ada ambang "tinggi". Peta kategori bersebelahan & angka ambang tidak ada di dokumen/repo. | Probe: CROSS_SELL tetap eligible walau semua kategori sudah dibeli, dan walau propensity 0.01. |
| C2 | ~~SERVICE_REMINDER tanpa aturan~~ → **DITUTUP sebagian (Revisi 5).** Aturan tim diterapkan: ACTIVE/LOYAL + `days_until_replenishment <= 7`, data kosong = tidak eligible. **Data jadwal belum ada di data sintetis** (Moses), sehingga aksi belum akan terpilih. | `evaluator.py`; `target_definitions.md` §3.1 |
| C3 | ~~Threshold 0.0 membuat EV 0.0 lolos~~ → **DITUTUP (Revisi 5).** `min_ev_threshold` default Rp 1.000; saat skor kedaluwarsa / `None` hasilnya `NO_ACTION` dengan `no_action_reason = BELOW_MIN_EV`. | `engine.py`; `test_nba_engine.py` (`TestMinEvThreshold`) |
| C4 | **RELATIONSHIP_MANAGER_CONTACT**: Bab 4 menyebut juga "atau keluhan aktif". Saat ada komplain aktif mesin hanya memilih `COMPLAINT_RESOLUTION`, RM tidak pernah jadi kandidat. Perlu diputuskan apakah Task RM boleh bersama komplain. | Probe. |
| C5 | ~~Label tier CLV ambigu~~ → **DITUTUP, bukan bug.** `target_definitions.md` §2.2 memetakan ≥ 1jt = `PLATINUM`, 500rb–1jt = `GOLD` ("Tinggi"), 200–500rb = `SILVER` ("Sedang"). RETENTION_OUTREACH menolak `SILVER` sudah benar. `BRONZE` hanya `membership_tier` di data Moses, bukan tier CLV. | `target_definitions.md` §2.2 |
| C6 | ~~Inkonsistensi At Risk vs Dormant~~ → **DITUTUP.** `target_definitions.md` §3 dan `services/data/segmentation/snapshot.py` (Moses) sama-sama: AT_RISK = 91–180 hari, DORMANT = 181–365 hari. WIN_BACK untuk `DORMANT` sudah benar; teks Bab 4 Requirement yang keliru. | `target_definitions.md` §3; `snapshot.py` |
| C7 | **RETENTION_OUTREACH**: Bab 4 dan trigger di `catalogue.py` menulis "Churn Risk HIGH"; kode menerima `HIGH` dan `VERY_HIGH`. Teks katalog dan aturan perlu disamakan. | Probe + `catalogue.py` |
| C8 | ~~Pagu diskon & kata terlarang belum ada~~ → **DITUTUP (Revisi 5)** dengan keputusan tim: pagu 30%, batas per band, daftar 7 kata terlarang, eskalasi `INCENTIVE_ESCALATED`. Catatan: kata `medis` memblokir juga "non-medis" (false positive diketahui). | `safety.py`, `generator.py` |

Poin C1–C7 menyangkut kode yang **sudah ada sebelum Fase 2** (`engine.py`/`evaluator.py` memindahkan aturan lama apa adanya) dan/atau data yang belum ada; saya tidak mengubahnya agar tidak mengarang aturan.

### D. Terkait Micro-task 1 (tidak berubah)
- Migrasi `0007_create_action_catalogue` bentrok dengan `0007_pipeline_runs` di `main` (dua head Alembic) dan menyentuh `migrations/`/`api/models.py` milik James.
- ID aksi di seed migrasi berbeda dengan K-06 / `catalogue.py` (K-06 + `catalogue.py` dipakai di Fase 2).

---

## REVISI 2 — Koreksi Fase 2 akibat evaluasi Fase 1

Dilakukan setelah `target_definitions.md` v1.1 dan kontrak K-06/K-07/K-10 diperbaiki (lihat `fase1.md`).

| # | Koreksi | Berkas | Bukti / sumber |
|---|---|---|---|
| R2-1 | `catalogue.py` tidak punya `required_fact_package` (wajib K-06): 11/11 aksi tidak valid. Field ditambahkan; `export_k06_catalogue()` dan `action_to_k06_dict()` menghasilkan dokumen K-06 yang **valid terhadap skema**. | `services/decision/nba/catalogue.py` | `test_contracts.py`, `test_catalogue_k06.py` (xfail Fase 1 dihapus) |
| R2-2 | Isi `required_fact_package` **tidak ditebak**: diturunkan dengan uji sensitivitas (ubah satu field, lihat apakah kelayakan/EV berubah) pada `check_business_eligibility` dan `ev_calculator`. Test mengulang uji itu sehingga daftar tidak bisa menyimpang dari aturan. | `catalogue.py`, `test_catalogue_k06.py` | Hasil: mis. `CROSS_SELL` = `clv_amount, lifecycle_stage, propensity_purchase`; `SERVICE_REMINDER` = `clv_amount` saja (tidak ada aturan kelayakan). `COMPLAINT_RESOLUTION` = `complaint_ticket_status`; NO_ACTION = kosong (aturan if/then K-06). |
| R2-3 | Consent tak dikenal dianggap **diizinkan** (default `True`), bertentangan dengan K-10 / Panduan Minggu 3. Ditambah `CustomerConsent.from_k10(doc, now)`: hanya `status=OPT_IN` + `effective_permission=ALLOWED` + `valid_until` belum lewat yang diizinkan; kanal tidak tercantum / UNKNOWN / EXPIRED / BLOCKED = diblokir; global OPT_OUT → `global_opt_out`; global UNKNOWN/EXPIRED/BLOCKED → semua kanal diblokir. Kanal `phone` (ada di K-10) ditambahkan. Default dataclass **tidak diubah** (107 test lama bergantung padanya); kini tertulis di docstring bahwa data nyata wajib lewat `from_k10`. | `services/decision/policy/suppression.py` | `test_policy.py` (`TestConsentFromK10`) |
| R2-4 | Aksi yang **seluruh kanalnya** diblokir consent masih bisa terpilih dengan `channel_selected = None` (tidak koheren). Kini kandidat itu diblokir (`blocked_gate = CUSTOMER_CONSENT`); bila semua kandidat terblokir → `NO_ACTION` + `ALL_CANDIDATES_BLOCKED`. `CONSENT_CHECK` memuat `candidates_blocked_by_channel_consent` dan berstatus `CHANNEL_CONSENT_BLOCKED` bila seluruh kandidat layak tak punya kanal. Kanal internal (`task_rm`, `branch`) tidak terkena consent pemasaran. | `evaluator.py` (`check_channel_availability`), `engine.py` | Requirement Bab 3 masukan 3 ("kanal ini"); K-10; `test_nba_engine.py` (`TestChannelConsent`) |
| R2-5 | Matriks segmen→aksi (`target_definitions.md` §3.1, 9 segmen) kini **dikunci oleh test** yang membaca tabel dokumen dan membandingkannya dengan perilaku engine. Hasil: engine sudah sesuai; 4 segmen "Belum ditetapkan" memang tidak punya aksi segmen-spesifik. | `test_lifecycle_matrix.py` (14 test) | `target_definitions.md` §3.1 |
| R2-6 | Docstring `AIScores.lifecycle_stage` mendaftar 9 segmen. | `engine.py` | `target_definitions.md` §3 |
| R2-7 | `test_contracts.py` memvalidasi 6 kontrak, aturan if/then K-06/K-10, sinkron konstanta doc↔kode, dan definisi churn 90 hari ke depan. | `tests/decision/test_contracts.py` | `fase1.md` |
| R2-8 | Dua temuan ruff bawaan `catalogue.py` ikut hilang (import dirapikan, `field` kini terpakai). | `catalogue.py` | `ruff check` |

**[PERLU KONFIRMASI] arti `required_fact_package`:** K-06 (teks buatan Fase 1) mendefinisikannya sebagai fakta untuk *evaluasi kelayakan aksi*, sedangkan Panduan Minggu 8 memakai istilah "Fact Package" untuk bahan pesan nudge. Saya mengikuti definisi K-06 (diturunkan dari kode). Variabel pesan tetap diatur terpisah oleh `nudge/generator.py` (`required_facts()`, whitelist 4 variabel). Jika yang dimaksud adalah variabel pesan, isi daftar ini perlu diganti dan `RM`/`COMPLAINT_RESOLUTION` (tanpa template) butuh keputusan.

**Belum diubah karena menunggu keputusan:** C1–C4, C7, C8 di atas, serta cakupan opt-out (target_definitions §4.2 [PERLU KONFIRMASI]). Perilaku saat ini sudah sesuai catatan v1.1: opt-out global memblokir semua; opt-out per kanal menutup kanal itu saja.

## REVISI 3 — Perbaikan CI: kegagalan type checking (mypy)

**Gejala:** job CI "Run Type Checking (mypy)" gagal dengan 4 error `arg-type` di `services/decision/nba/engine.py` (baris 381, 398, 423, 457):
`selected_action` bertipe `Action | None` dilewatkan ke `_build_result` yang mewajibkan `Action`.

**Penyebab:** `get_action()` di `catalogue.py` mengembalikan `Optional[Action]` (benar untuk pencarian umum). `NBAEngine` memakainya untuk aksi inti
(`NO_ACTION`, `COMPLAINT_RESOLUTION`) sehingga tipe `Optional` menular ke empat pemanggilan `_build_result`.
**Error yang sama sudah ada di `main` sebelum Fase 2** (mypy pada `main` asli melaporkan 4 error `arg-type` yang sama, plus 1 error `callable` di engine lama);
nomor baris bergeser karena engine direfaktor.

**Perbaikan:**
| Berkas | Perubahan |
|---|---|
| `services/decision/nba/catalogue.py` | Fungsi baru `require_action(action_id) -> Action`: aksi WAJIB ada, `KeyError` yang jelas bila hilang. `get_action()` tidak diubah. |
| `services/decision/nba/engine.py` | `self._no_action: Action = require_action("NO_ACTION")` dan `require_action("COMPLAINT_RESOLUTION")` menggantikan `get_action(...)`. Tidak ada `# type: ignore`, tidak ada `assert`. |
| `tests/decision/test_catalogue_k06.py` | 3 test regresi (`require_action` untuk aksi inti, `KeyError` untuk ID tak dikenal, `NBAEngine._no_action` tidak pernah `None`). |

**Verifikasi setara CI** (Python 3.11.15, dependency dari `requirements-dev.txt`, mypy 1.20.2 — rentang yang diizinkan `>=1.10,<2.0`):
`ruff check services tests/decision` bersih; `mypy services api worker --ignore-missing-imports` → *no issues found in 76 source files*; `black --check` (daftar CI) lulus;
`pytest tests/security/test_allowlist.py` lulus; seluruh suite (di luar `tests/integration`) → 514 passed dengan `jsonschema` terpasang.

**Catatan CI:**
1. CI memakai **Python 3.11** dan `ruff check .` pada **seluruh repo**; `jsonschema` **tidak ada** di `requirements-dev.txt`, sehingga 7 modul/kelompok test (kontrak K-06…K-11, validasi K-07) otomatis di-*skip* di CI. Usul ke tim: tambahkan `jsonschema` ke `requirements-dev.txt` (berkas bersama, bukan wilayah Christ).
2. `ruff check .` menandai 6 temuan di `docs/christ_business/reference/test/*.py` (import tak terurut / tak terpakai) pada snapshot `main` yang saya pegang. Jika CI-mu juga menandainya: `ruff check --fix docs/christ_business/reference/test`
   (hanya merapikan import, perilaku test tidak berubah).
3. Langkah CI setelah mypy: `alembic upgrade head`. Jika migrasi Micro-task 1 (`0007_create_action_catalogue`) ikut ter-merge, langkah itu akan gagal karena dua head Alembic (lihat `fase1.md` B7).

## REVISI 4 — Perbaikan CI: kegagalan format (`black --check`)

**Gejala:** job CI gagal di langkah *Verify Python Formatting*: `would reformat .../tests/decision/test_contracts.py`, "8 files would be reformatted, 127 files would be left unchanged" (135 file diperiksa → CI memeriksa **seluruh repo**).

**Penyebab (terbukti dengan menjalankan black versi CI, `>=24.0,<26.0`, Python 3.11):**
1. Empat file `services/decision/{nba/catalogue.py, nba/engine.py, policy/fatigue.py, policy/suppression.py}` **tidak pernah diformat black** sejak ada di `main`; perubahan Fase 2 mengubah isinya tetapi tidak memformat penuh.
2. Lima file test referensi `docs/christ_business/reference/test/` (`conftest.py`, `test_catalogue.py`, `test_engine.py`, `test_fatigue.py`, `test_suppression.py`) juga belum terformat (dan ruff menandai 6 temuan import di sana).
3. `tests/decision/test_contracts.py`: versi dari paket **lolos** black di semua versi 24.1–26.1. Yang diketahui menyebabkan file ditandai: **tidak ada newline di akhir file atau dua newline di akhir** (terbukti) — umum terjadi saat isi file disalin-tempel ke editor. Penyebab pasti di salinanmu tidak bisa saya pastikan; perintah di bawah memperbaikinya apa pun sebabnya.

**Perbaikan:** keempat file `services/decision/` dan seluruh `tests/decision/` diformat dengan black 25.12.0 (versi CI). Hasil: lolos di black 24.1.1, 24.10.0, 25.1.0, 25.12.0, dan 26.1.0. Bukti perilaku tidak berubah: AST keempat file identik sebelum/sesudah; 406 test lulus; ruff dan mypy bersih.
Untuk lima file test referensi disediakan paket **opsional** (`opsional_format_reference_test/`) agar tidak menimpa perubahanmu sendiri.

**Cara memeriksa dan memperbaiki di mesinmu (hanya area Christ):**
```
pip install -r requirements-dev.txt        # versi black/ruff sama dengan CI
black --check .                            # lihat daftar file yang gagal
black services/decision tests/decision docs/christ_business/reference/test
ruff check --fix docs/christ_business/reference/test
```
**Jangan menjalankan `black .` pada seluruh repo.** Pada snapshot `main` yang saya pegang, black juga menandai file milik orang lain:
`generator/generate.py`, `scripts/benchmark_james_trace.py`, `services/data/customer360/publish.py`, `tests/data/test_generator_quality.py`, `tests/security/test_allowlist.py`.
Jika CI-mu masih menandainya, itu tanggung jawab pemiliknya (Moses/James) — jangan ikut memformatnya agar tidak menimbulkan konflik merge.

**Pencegahan:** ekstrak zip (byte-identik) daripada menyalin-tempel isi file; selalu jalankan `black --check` dan `ruff check .` sebelum commit.

## REVISI 5 — Keputusan tim (K-08 holdout, threshold EV, pagu diskon, SERVICE_REMINDER)

Sumber: penjelasan tim atas masalah 1 dan 6 (merujuk FRD/TRD/SRS yang **tidak tersedia** bagi saya, sehingga tidak bisa diverifikasi). Setiap butir diperiksa terhadap repo; yang bertentangan dengan fakta repo **tidak diterapkan** (lihat tabel kedua).

**Diterapkan**
| # | Perubahan | Berkas |
|---|---|---|
| R5-1 | K-08: `control_holdout_ratio` (default 0.10, `0 < x < 1`) dan `random_seed` (integer, wajib bila holdout diisi); `ab_test_ratio` default 50 → 90. **Aditif**: dokumen K-08 lama tetap valid, `exposure_window` tidak diubah namanya. | `contracts/K-08_campaign_identifier.json` |
| R5-2 | `min_ev_threshold` default 0.0 → **Rp 1.000**; alasan baru `BELOW_MIN_EV` (engine + enum K-07). | `engine.py`, `K-07` |
| R5-3 | `SERVICE_REMINDER`: ACTIVE/LOYAL + `days_until_replenishment <= 7`; field baru `EligibilityProfile.days_until_replenishment` (None = tidak eligible). `required_fact_package` dan trigger katalog diperbarui. | `evaluator.py`, `engine.py`, `catalogue.py` |
| R5-4 | Pagu diskon global **30%**; batas per band: Tanpa Insentif 0%, Rendah ≤ 10%, Sedang ≤ 20%, Tinggi ≤ 30% (band lain → pagu global). Pelanggaran → `MESSAGE_BLOCKED_BY_GUARDRAIL` **dan** `escalation = INCENTIVE_ESCALATED`. | `safety.py`, `generator.py` |
| R5-5 | `FORBIDDEN_TERMS` = 7 istilah dari tim (kata utuh, tidak peka huruf besar/kecil). | `safety.py` |
| R5-6 | `target_definitions.md` v1.2 (matriks §3.1, konstanta, riwayat revisi); test sinkronisasi dokumen↔kode↔K-08. | docs, `test_contracts.py` |

**Tidak diterapkan karena bertentangan dengan fakta repo / perlu keputusan**
| # | Usulan | Alasan |
|---|---|---|
| X1 | Menulis ulang K-08 dengan `exposure_start_window`/`exposure_end_window` dan `state` wajib | Mengganti nama field yang sudah beku (`exposure_window` objek `start_time`/`end_time`, wajib menurut Panduan Minggu 3), memutus dokumen lama, dan `state` bertabrakan dengan field `status` yang sudah ada (enum berbeda). |
| X2 | Objek `treatment_allocation` dengan `treatment_share` 0.90 | Redundan dan bisa bertentangan dengan `control_holdout_ratio`; porsi treatment cukup diturunkan (1 − holdout). |
| X3 | Batas `control_holdout_ratio` 0.05–0.50 dan seed default 20260906 | Tidak ada sumber yang bisa diverifikasi; batas dibuat 0 < x < 1 dan seed tanpa default. Bisa dikencangkan jika ada sumber. |
| X4 | Batas biaya insentif per band Rp 15.000 / 30.000 / 50.000 | Bertentangan dengan konstanta EV yang sudah ada (`ev_calculator.INCENTIVE_COST_RULES`: Rp 25.000 / 75.000 / 150.000). Menggantinya mengubah nilai EV semua keputusan; **butuh keputusan mana yang benar**. |
| X5 | Pita insentif bernama NONE/LOW/MEDIUM/HIGH | K-06 memiliki 6 band; `Band Tinggi` tidak dipakai aksi mana pun dan `Diskon Berbatas Waktu` (RETENTION_OUTREACH) serta `Hadiah / Poin Loyalitas` tidak punya batas persentase di penjelasan → memakai pagu global. |
| X6 | Komplain berat = status OPEN **atau IN_PROGRESS** | Requirement Bab 4 dan kode: hanya `OPEN_SEVERE_COMPLAINT` yang memblokir (IN_PROGRESS tidak; ada test yang mengunci ini). Perlu keputusan jika ingin diubah. |
| X7 | "4 segmen tanpa aksi" = opt-out, komplain berat, jenuh kontak, holdout 10% | Itu kondisi yang sudah ditangani (atau Fase 3), bukan 4 **segmen lifecycle** yang masih "Belum ditetapkan" (`CHURNED`, `REACTIVATED`, `OCCASIONAL`, `NEVER_TRANSACTED`). Masih terbuka. |
| X8 | Field `last_purchase_date` / `replenishment_cycle_days` "ada di skema sintetis" | Tidak ditemukan di `generator/`, `fixtures/`, `contracts/`, `services/data/`. Moses harus menyediakannya. |

**Masih terbuka:** C1 (CROSS_SELL), C4 (RM vs komplain), C7 (teks trigger RETENTION), cakupan opt-out, X4, X6, X7.

## Verifikasi Akhir

- `python -m pytest tests/decision -q` → **369 passed**
- `python -m pytest docs/christ_business/reference/test -q` → **107 passed**
- `ruff check services/decision tests/decision` → bersih; `black --check` file baru + `tests/decision` → bersih.

## Catatan untuk James

```python
from services.decision.nba.engine import NBAEngine

engine = NBAEngine()   # opsional: ev_min_threshold=..., score_validity_days=...
record = engine.decide(
    customer_id="C001",
    ai_scores=ai_scores,              # boleh None -> degraded_input=True
    consent=consent, complaint_tickets=tickets, contact_history=history,
    eligibility=eligibility, product_suitability=suitability,
    correlation_id=x_correlation_id,  # pola ^[A-Za-z0-9._:-]{1,128}$
)
payload = record.to_dict()            # dict bentuk K-07 (+ degraded_input, no_action_reason)
```

```python
# Consent dari dokumen K-10: UNKNOWN / EXPIRED / kanal tidak tercantum = diblokir
from services.decision.policy.suppression import CustomerConsent
consent = CustomerConsent.from_k10(k10_document)          # opsional: now=datetime.now(timezone.utc)

# Katalog aksi dalam bentuk dokumen K-06 (valid terhadap skema)
from services.decision.nba.catalogue import export_k06_catalogue
k06_document = export_k06_catalogue()
```

```python
from services.decision.nudge.generator import generate_nudge, approve_draft

draft = generate_nudge("C001", record.selected_action_id, record.channel_selected,
                       {"first_name": "...", "preferred_branch": "...",
                        "points_balance": 0, "offer_validity": "..."})
# draft.status: GENERATED_DRAFT | MESSAGE_BLOCKED_BY_GUARDRAIL | DRAFT_REJECTED_MISSING_FACTS | ...
# Rilis hanya jika draft.is_releasable (setelah approve_draft(draft, approver_id) oleh manusia).
```
Selama `MAX_DISCOUNT_PERCENT` belum diisi, pesan yang memuat diskon persentase pasti diblokir (template bawaan tidak memuat diskon).
